# NodeJS From the Fundamentals to the Advanced Concepts (Project: A full e-commerce backend)
This is an attempt to understand node JS far beyond the express JS framework, digging deeply into the express framework and having a good time while buiding a robust e-commerce project.
